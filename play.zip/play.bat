@echo off
REM RO3Emu player launcher. Put this file next to RO3Emu.exe (from RO3Emu-win-x64.zip) and double-click it.
REM First run: downloads the game client from Genesis (about 24 GB) into GAME_DIR, then joins the server.
REM Later runs: joins the server straight away.

set SERVER=51.222.36.152
set GAME_DIR=%~dp0ROO_PC

cd /d "%~dp0"

if not exist "%~dp0RO3Emu.exe" (
    echo RO3Emu.exe not found next to this file.
    echo Download RO3Emu-win-x64.zip from https://github.com/aethai/ro3emu-server/releases/latest
    echo and extract it into this folder.
    pause
    exit /b 1
)

if not exist "%GAME_DIR%\ro3.exe" (
    echo No game client found in "%GAME_DIR%".
    echo Downloading it from Genesis update servers, about 24 GB. This takes a while.
    echo.
    RO3Emu.exe install "%GAME_DIR%" --yes
    if errorlevel 1 (
        echo.
        echo Download failed. If your ISP blocks the Genesis mirror, connect through Cloudflare WARP or a VPN and run this again.
        pause
        exit /b 1
    )
)

echo Joining server %SERVER% ...
RO3Emu.exe join %SERVER% --client "%GAME_DIR%"
if errorlevel 1 pause
